# NexusUI 

##### Version 2

NexusUI is a JavaScript toolkit of web audio interfaces and other helper methods for building instruments in the browser.

For more info, see the [website](http://nexus-js.github.io/ui/).

For documentation and tutorials, see [the API](http://nexus-js.github.io/ui/api/).
